#!/bin/sh
exec autoreconf -fis
